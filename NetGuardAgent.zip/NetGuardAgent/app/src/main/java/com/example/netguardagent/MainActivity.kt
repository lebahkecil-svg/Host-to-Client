package com.example.netguardagent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusView: TextView
    private lateinit var wifiView: TextView
    private lateinit var nameInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusView = findViewById(R.id.status)
        wifiView = findViewById(R.id.wifiInfo)
        nameInput = findViewById(R.id.deviceNameInput)
        val sharedPath = findViewById<TextView>(R.id.sharedPath)
        val receivedPath = findViewById<TextView>(R.id.receivedPath)
        val toggleBtn = findViewById<Button>(R.id.toggleBtn)
        val saveNameBtn = findViewById<Button>(R.id.saveNameBtn)

        nameInput.setText(DeviceIdentity.deviceName(this))
        sharedPath.text = getExternalFilesDir(null)?.path + "/Shared"
        receivedPath.text = getExternalFilesDir(null)?.path + "/Received"

        saveNameBtn.setOnClickListener {
            val n = nameInput.text.toString().trim()
            if (n.isNotEmpty()) {
                DeviceIdentity.setDeviceName(this, n)
                Toast.makeText(this, "Nama disimpan: $n", Toast.LENGTH_SHORT).show()
            }
        }

        toggleBtn.setOnClickListener {
            ensureNotifPermission()
            if (AgentForegroundService.isRunning) {
                stopService(Intent(this, AgentForegroundService::class.java))
            } else {
                val i = Intent(this, AgentForegroundService::class.java)
                ContextCompat.startForegroundService(this, i)
            }
            // beri jeda singkat lalu refresh tampilan status
            statusView.postDelayed({ refreshStatus() }, 500)
        }

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val running = AgentForegroundService.isRunning
        statusView.text = "Status: " + if (running) "AKTIF, port ${AgentForegroundService.PORT}" else "tidak aktif"
        findViewById<Button>(R.id.toggleBtn).text =
            if (running) "Matikan mode agen" else "Aktifkan mode agen"

        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val ssid = try { wm.connectionInfo?.ssid?.trim('"') } catch (e: Exception) { null }
        wifiView.text = "Wi-Fi: " + (ssid ?: "tidak diketahui")
    }

    private fun ensureNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
    }
}
