package com.example.netguardagent

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log

/**
 * Mendaftarkan agen ini ke jaringan lokal lewat NSD (mDNS/Bonjour)
 * supaya aplikasi Controller bisa menemukannya otomatis, tanpa perlu
 * memasukkan alamat IP secara manual.
 */
class Discovery(private val ctx: Context) {
    companion object { const val SERVICE_TYPE = "_netguard._tcp." }

    private val nsd by lazy { ctx.getSystemService(Context.NSD_SERVICE) as NsdManager }
    private var listener: NsdManager.RegistrationListener? = null

    fun register(port: Int) {
        val info = NsdServiceInfo().apply {
            serviceName = DeviceIdentity.deviceName(ctx)
            serviceType = SERVICE_TYPE
            setPort(port)
        }
        listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {
                Log.i("NetGuardAgent", "Terdaftar sebagai ${i.serviceName}")
            }
            override fun onRegistrationFailed(i: NsdServiceInfo, code: Int) {
                Log.e("NetGuardAgent", "Gagal daftar NSD: $code")
            }
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, code: Int) {}
        }
        try {
            nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (e: Exception) {
            Log.e("NetGuardAgent", "registerService error: ${e.message}")
        }
    }

    fun unregister() {
        listener?.let { try { nsd.unregisterService(it) } catch (_: Exception) {} }
        listener = null
    }
}
