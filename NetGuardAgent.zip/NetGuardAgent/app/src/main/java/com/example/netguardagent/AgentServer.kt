package com.example.netguardagent

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Server HTTP ringan di tiap perangkat agen.
 * Endpoint:
 *  GET  /info               -> identitas perangkat (nama, tipe)
 *  GET  /files              -> daftar file di folder "Shared"
 *  GET  /download?name=X    -> unduh file dari folder "Shared"
 *  POST /upload?name=X      -> simpan file ke folder "Received" (body = isi file apa adanya)
 */
class AgentServer(private val ctx: Context, port: Int) : NanoHTTPD(port) {

    private val sharedDir = File(ctx.getExternalFilesDir(null), "Shared").apply { mkdirs() }
    private val receivedDir = File(ctx.getExternalFilesDir(null), "Received").apply { mkdirs() }

    fun sharedFolder(): File = sharedDir
    fun receivedFolder(): File = receivedDir

    override fun serve(session: IHTTPSession): Response {
        return try {
            when {
                session.uri == "/info" -> info()
                session.uri == "/files" -> listFiles()
                session.uri == "/download" -> download(session)
                session.uri == "/upload" && session.method == Method.POST -> upload(session)
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "not found")
            }
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "error: ${e.message}")
        }
    }

    private fun info(): Response {
        val o = JSONObject()
        o.put("name", DeviceIdentity.deviceName(ctx))
        o.put("type", "android")
        o.put("agent", "netguard")
        return json(o.toString())
    }

    private fun listFiles(): Response {
        val arr = JSONArray()
        sharedDir.listFiles()?.forEach { f ->
            if (f.isFile) {
                val o = JSONObject()
                o.put("name", f.name)
                o.put("size", f.length())
                arr.put(o)
            }
        }
        return json(arr.toString())
    }

    private fun download(session: IHTTPSession): Response {
        val name = session.parameters["name"]?.firstOrNull()
            ?: return newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", "parameter 'name' wajib diisi")
        val target = File(sharedDir, name)
        if (!target.exists() || !target.canonicalPath.startsWith(sharedDir.canonicalPath)) {
            return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "file tidak ditemukan")
        }
        return newFixedLengthResponse(Response.Status.OK, "application/octet-stream", target.inputStream(), target.length())
    }

    private fun upload(session: IHTTPSession): Response {
        val name = session.parameters["name"]?.firstOrNull()
            ?: return newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", "parameter 'name' wajib diisi")
        val safeName = File(name).name // cegah path traversal
        val target = File(receivedDir, safeName)
        val files = HashMap<String, String>()
        session.parseBody(files) // NanoHTTPD menaruh body mentah di file sementara untuk POST besar
        val tmpPath = files["postData"]
        if (tmpPath != null) {
            File(tmpPath).copyTo(target, overwrite = true)
        } else {
            FileOutputStream(target).use { it.write(session.inputStream.readBytes()) }
        }
        return json(JSONObject().put("saved", safeName).toString())
    }

    private fun json(body: String) = newFixedLengthResponse(Response.Status.OK, "application/json", body)
}

object DeviceIdentity {
    fun deviceName(ctx: Context): String {
        val sp = ctx.getSharedPreferences("agent", Context.MODE_PRIVATE)
        return sp.getString("device_name", android.os.Build.MODEL) ?: android.os.Build.MODEL
    }
    fun setDeviceName(ctx: Context, name: String) {
        ctx.getSharedPreferences("agent", Context.MODE_PRIVATE).edit().putString("device_name", name).apply()
    }
}
