package com.example.netguardagent

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Service latar depan: menjaga server HTTP agen tetap hidup selama
 * perangkat terhubung ke jaringan kerja, dan menampilkan notifikasi
 * tetap supaya pemakai tahu perangkat sedang dalam mode kerja/remote.
 */
class AgentForegroundService : Service() {

    companion object {
        const val PORT = 8742
        const val CHANNEL_ID = "netguard_agent"
        const val NOTIF_ID = 1
        var isRunning = false
            private set
    }

    private var server: AgentServer? = null
    private var discovery: Discovery? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        startAgent()
        isRunning = true
        return START_STICKY
    }

    private fun startAgent() {
        if (server != null) return
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        multicastLock = wifi.createMulticastLock("netguard_lock").apply {
            setReferenceCounted(true); acquire()
        }
        server = AgentServer(applicationContext, PORT).also { it.start() }
        discovery = Discovery(applicationContext).also { it.register(PORT) }
    }

    private fun stopAgent() {
        discovery?.unregister(); discovery = null
        server?.stop(); server = null
        multicastLock?.let { if (it.isHeld) it.release() }; multicastLock = null
    }

    override fun onDestroy() {
        stopAgent()
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "NetGuard Agent", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NetGuard Agent aktif")
            .setContentText("Terhubung ke jaringan kerja, siap bertukar data")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setOngoing(true)
            .build()
}
