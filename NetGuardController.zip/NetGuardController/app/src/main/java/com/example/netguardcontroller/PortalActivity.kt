package com.example.netguardcontroller

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File

class PortalActivity : AppCompatActivity() {

    private lateinit var apkStatus: TextView
    private lateinit var serverUrlView: TextView
    private lateinit var toggleBtn: Button
    private lateinit var qrImage: ImageView

    private val pickApk = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveAgentApk(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_portal)

        apkStatus = findViewById(R.id.apkStatus)
        serverUrlView = findViewById(R.id.serverUrl)
        toggleBtn = findViewById(R.id.toggleServerBtn)
        qrImage = findViewById(R.id.qrImage)

        findViewById<Button>(R.id.pickApkBtn).setOnClickListener {
            pickApk.launch("application/vnd.android.package-archive")
        }

        toggleBtn.setOnClickListener {
            ensureNotifPermission()
            if (LandingService.isRunning) {
                stopService(Intent(this, LandingService::class.java))
            } else {
                ContextCompat.startForegroundService(this, Intent(this, LandingService::class.java))
            }
            toggleBtn.postDelayed({ refreshState() }, 500)
        }

        refreshApkStatus()
        refreshState()
    }

    override fun onResume() {
        super.onResume()
        refreshApkStatus()
        refreshState()
    }

    private fun agentApkFile() = File(filesDir, LandingServer.APK_FILENAME)

    private fun saveAgentApk(uri: android.net.Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                agentApkFile().outputStream().use { output -> input.copyTo(output) }
            }
            Toast.makeText(this, "APK Agent disiapkan", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menyalin APK: ${e.message}", Toast.LENGTH_SHORT).show()
        }
        refreshApkStatus()
    }

    private fun refreshApkStatus() {
        val ok = agentApkFile().exists()
        apkStatus.text = "APK Agent: " + if (ok) "siap (${agentApkFile().length() / 1024} KB)" else "belum disiapkan"
    }

    private fun refreshState() {
        val running = LandingService.isRunning
        toggleBtn.text = if (running) "Matikan portal unduh" else "Nyalakan portal unduh"

        if (running) {
            val ip = HotspotIp.detect() ?: "192.168.43.1"
            val url = "http://$ip:${LandingService.PORT}"
            serverUrlView.text = "Alamat: $url"
            val bmp = QrGenerator.generate(url)
            qrImage.setImageBitmap(bmp)
            qrImage.visibility = android.view.View.VISIBLE
        } else {
            serverUrlView.text = "Alamat: -"
            qrImage.visibility = android.view.View.GONE
        }
    }

    private fun ensureNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
    }
}
