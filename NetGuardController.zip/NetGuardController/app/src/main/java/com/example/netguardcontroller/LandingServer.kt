package com.example.netguardcontroller

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import java.io.File

/**
 * Server halaman unduh yang dibuka lewat QR saat perangkat baru tersambung
 * ke hotspot. Menyajikan satu halaman instruksi dan file APK Agent.
 */
class LandingServer(private val ctx: Context, port: Int) : NanoHTTPD(port) {

    companion object {
        const val APK_FILENAME = "netguard-agent.apk"
    }

    private fun apkFile(): File = File(ctx.filesDir, APK_FILENAME)

    fun hasApk(): Boolean = apkFile().exists()

    fun saveApk(bytes: ByteArray) {
        apkFile().writeBytes(bytes)
    }

    override fun serve(session: IHTTPSession): Response {
        return when (session.uri) {
            "/", "/index.html" -> newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", landingHtml())
            "/agent.apk" -> serveApk()
            else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "not found")
        }
    }

    private fun serveApk(): Response {
        val f = apkFile()
        if (!f.exists()) {
            return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "APK belum disiapkan admin")
        }
        val res = newFixedLengthResponse(
            Response.Status.OK,
            "application/vnd.android.package-archive",
            f.inputStream(),
            f.length()
        )
        res.addHeader("Content-Disposition", "attachment; filename=\"$APK_FILENAME\"")
        return res
    }

    private fun landingHtml(): String = """
        <!DOCTYPE html>
        <html lang="id">
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <title>Pasang aplikasi kerja</title>
          <style>
            body { font-family: sans-serif; background:#111; color:#fff; text-align:center; padding:40px 20px; }
            h1 { font-size:22px; margin-bottom:8px; }
            p { font-size:16px; color:#ccc; line-height:1.5; }
            a.btn { display:inline-block; margin-top:24px; padding:16px 32px; background:#2E7D32;
                    color:#fff; text-decoration:none; border-radius:8px; font-size:18px; }
          </style>
        </head>
        <body>
          <h1>Install untuk tetap terhubung.</h1>
          <p>Ijinkan sumber tidak dikenal di pengaturan.</p>
          <a class="btn" href="/agent.apk">Unduh aplikasi</a>
        </body>
        </html>
    """.trimIndent()
}
