package com.example.netguardcontroller

/** Satu baris di daftar: perangkat dengan agen (whitelist) atau tanpa agen (blacklist). */
data class AgentDevice(
    val name: String,
    val host: String,
    val port: Int,
    val whitelisted: Boolean
) {
    val baseUrl: String get() = "http://$host:$port"
    /** Kunci unik untuk membedakan baris di daftar (host dipakai karena MAC jarang tersedia). */
    val key: String get() = "$host:$port"
}
