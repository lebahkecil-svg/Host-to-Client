package com.example.netguardcontroller

import android.content.ContentResolver
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch
import java.io.File

class DeviceActivity : AppCompatActivity() {

    private lateinit var device: AgentDevice
    private lateinit var client: AgentClient
    private lateinit var adapter: FileAdapter

    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) sendFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_device)

        val name = intent.getStringExtra("name") ?: "Perangkat"
        val host = intent.getStringExtra("host") ?: ""
        val port = intent.getIntExtra("port", 0)
        device = AgentDevice(name, host, port, whitelisted = true)
        client = AgentClient(device)

        findViewById<TextView>(R.id.deviceTitle).text = name
        findViewById<TextView>(R.id.deviceSub).text = "$host:$port"

        val list = findViewById<RecyclerView>(R.id.fileList)
        adapter = FileAdapter(emptyList()) { file -> downloadFile(file) }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<Button>(R.id.sendBtn).setOnClickListener { pickFile.launch("*/*") }

        refreshFiles()
    }

    private fun refreshFiles() {
        lifecycleScope.launch {
            try {
                val files = client.listFiles()
                adapter.submit(files)
            } catch (e: Exception) {
                Toast.makeText(this@DeviceActivity, "Gagal memuat daftar file: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun downloadFile(file: RemoteFile) {
        lifecycleScope.launch {
            try {
                val destDir = getExternalFilesDir("Downloads") ?: filesDir
                val saved = client.download(file.name, destDir)
                Toast.makeText(this@DeviceActivity, "Tersimpan: ${saved.path}", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this@DeviceActivity, "Gagal unduh: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendFile(uri: Uri) {
        val tmp = copyUriToTempFile(uri) ?: run {
            Toast.makeText(this, "Tidak bisa membaca file", Toast.LENGTH_SHORT).show(); return
        }
        lifecycleScope.launch {
            try {
                val ok = client.upload(tmp)
                Toast.makeText(
                    this@DeviceActivity,
                    if (ok) "Terkirim: ${tmp.name}" else "Gagal mengirim",
                    Toast.LENGTH_SHORT
                ).show()
                if (ok) refreshFiles()
            } catch (e: Exception) {
                Toast.makeText(this@DeviceActivity, "Gagal mengirim: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                tmp.delete()
            }
        }
    }

    /** Menyalin isi URI yang dipilih pengguna ke file sementara bernama asli, agar mudah diunggah. */
    private fun copyUriToTempFile(uri: Uri): File? {
        val resolver: ContentResolver = contentResolver
        val displayName = queryDisplayName(uri) ?: "berkas_${System.currentTimeMillis()}"
        val tmp = File(cacheDir, displayName)
        return try {
            resolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { output -> input.copyTo(output) }
            }
            tmp
        } catch (e: Exception) { null }
    }

    private fun queryDisplayName(uri: Uri): String? {
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        return name
    }
}
