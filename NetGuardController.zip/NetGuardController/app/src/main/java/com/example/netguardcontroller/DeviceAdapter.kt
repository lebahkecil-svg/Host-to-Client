package com.example.netguardcontroller

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DeviceAdapter(
    private var items: List<AgentDevice>,
    private val onClick: (AgentDevice) -> Unit
) : RecyclerView.Adapter<DeviceAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.name)
        val sub: TextView = v.findViewById(R.id.sub)
        val badge: TextView = v.findViewById(R.id.badge)
    }

    fun submit(newItems: List<AgentDevice>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_device, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val d = items[position]
        holder.name.text = d.name
        holder.sub.text = "${d.host}" + if (d.whitelisted) ":${d.port}" else " (tanpa agen)"
        if (d.whitelisted) {
            holder.badge.text = "✔ Whitelist — bisa tukar data"
            holder.badge.setTextColor(Color.parseColor("#2E7D32"))
        } else {
            holder.badge.text = "✖ Blacklist — koneksi saja"
            holder.badge.setTextColor(Color.parseColor("#C62828"))
        }
        holder.itemView.setOnClickListener { if (d.whitelisted) onClick(d) }
        holder.itemView.alpha = if (d.whitelisted) 1f else 0.6f
    }
}
