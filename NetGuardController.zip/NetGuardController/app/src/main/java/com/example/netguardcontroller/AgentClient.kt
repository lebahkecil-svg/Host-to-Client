package com.example.netguardcontroller

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class RemoteFile(val name: String, val size: Long)

/** Klien HTTP kecil untuk bicara ke satu agen (lihat daftar file, unduh, unggah). */
class AgentClient(private val device: AgentDevice) {

    suspend fun listFiles(): List<RemoteFile> = withContext(Dispatchers.IO) {
        val conn = URL("${device.baseUrl}/files").openConnection() as HttpURLConnection
        conn.connectTimeout = 3000; conn.readTimeout = 5000
        try {
            val body = conn.inputStream.bufferedReader().readText()
            val arr = JSONArray(body)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                RemoteFile(o.getString("name"), o.getLong("size"))
            }
        } finally { conn.disconnect() }
    }

    suspend fun download(name: String, destDir: File): File = withContext(Dispatchers.IO) {
        val enc = URLEncoder.encode(name, "UTF-8")
        val conn = URL("${device.baseUrl}/download?name=$enc").openConnection() as HttpURLConnection
        conn.connectTimeout = 3000; conn.readTimeout = 20000
        try {
            destDir.mkdirs()
            val out = File(destDir, name)
            conn.inputStream.use { input -> out.outputStream().use { output -> input.copyTo(output) } }
            out
        } finally { conn.disconnect() }
    }

    suspend fun upload(file: File): Boolean = withContext(Dispatchers.IO) {
        val enc = URLEncoder.encode(file.name, "UTF-8")
        val conn = URL("${device.baseUrl}/upload?name=$enc").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 3000; conn.readTimeout = 30000
        try {
            file.inputStream().use { input -> conn.outputStream.use { output -> input.copyTo(output) } }
            conn.responseCode in 200..299
        } finally { conn.disconnect() }
    }

    suspend fun ping(): Boolean = withContext(Dispatchers.IO) {
        try {
            val conn = URL("${device.baseUrl}/info").openConnection() as HttpURLConnection
            conn.connectTimeout = 1500; conn.readTimeout = 1500
            val ok = conn.responseCode == 200
            conn.disconnect(); ok
        } catch (e: Exception) { false }
    }
}
