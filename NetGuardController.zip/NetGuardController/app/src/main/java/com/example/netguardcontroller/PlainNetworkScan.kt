package com.example.netguardcontroller

import android.content.Context
import android.net.ConnectivityManager
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.net.Inet4Address
import java.net.InetAddress

/**
 * Pindai subnet dengan ping biasa untuk menemukan perangkat yang terhubung
 * ke jaringan tapi TIDAK menjalankan NetGuard Agent. Perangkat ini masuk
 * daftar blacklist: boleh pakai internet, tidak ikut pertukaran data.
 */
object PlainNetworkScan {

    private fun localAddress(ctx: Context): Pair<String, Int>? {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val lp = cm.getLinkProperties(cm.activeNetwork) ?: return null
        val la = lp.linkAddresses.firstOrNull { it.address is Inet4Address && !it.address.isLoopbackAddress }
            ?: return null
        return la.address.hostAddress!! to la.prefixLength
    }

    private fun toInt(ip: String) = ip.split(".").fold(0) { a, b -> (a shl 8) or b.toInt() }
    private fun toIp(v: Int) = "${v ushr 24 and 255}.${v ushr 16 and 255}.${v ushr 8 and 255}.${v and 255}"

    /** Mengembalikan IP yang hidup di jaringan tapi tidak ada di [knownAgentHosts]. */
    suspend fun findUnmanaged(ctx: Context, knownAgentHosts: Set<String>): List<String> = withContext(Dispatchers.IO) {
        val (selfIp, prefix) = localAddress(ctx) ?: return@withContext emptyList()
        val p = prefix.coerceIn(22, 30)
        val net = toInt(selfIp) and (-1 shl (32 - p))
        val count = 1 shl (32 - p)
        val gate = Semaphore(64)
        (1 until count - 1).map { off ->
            async {
                val ip = toIp(net + off)
                if (ip == selfIp || ip in knownAgentHosts) return@async null
                gate.withPermit {
                    try { if (InetAddress.getByName(ip).isReachable(500)) ip else null }
                    catch (e: Exception) { null }
                }
            }
        }.awaitAll().filterNotNull()
    }
}
