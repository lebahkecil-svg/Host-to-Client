package com.example.netguardcontroller

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: DeviceAdapter
    private lateinit var summary: TextView
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        summary = findViewById(R.id.summary)
        progress = findViewById(R.id.progress)
        val list = findViewById<RecyclerView>(R.id.list)
        val scanBtn = findViewById<Button>(R.id.scanBtn)

        adapter = DeviceAdapter(emptyList()) { device -> openDevice(device) }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        scanBtn.setOnClickListener { runScan() }
        findViewById<Button>(R.id.portalBtn).setOnClickListener {
            startActivity(Intent(this, PortalActivity::class.java))
        }
        runScan()
    }

    private fun openDevice(device: AgentDevice) {
        val i = Intent(this, DeviceActivity::class.java)
        i.putExtra("name", device.name)
        i.putExtra("host", device.host)
        i.putExtra("port", device.port)
        startActivity(i)
    }

    private fun runScan() {
        progress.visibility = android.view.View.VISIBLE
        summary.text = "Memindai…"
        lifecycleScope.launch {
            val agents = AgentDiscovery(this@MainActivity).discover()
            val unmanaged = PlainNetworkScan.findUnmanaged(
                this@MainActivity,
                agents.map { it.host }.toSet()
            )
            val blacklisted = unmanaged.map { ip -> AgentDevice(name = "Tidak dikenal", host = ip, port = 0, whitelisted = false) }
            val combined = agents + blacklisted
            adapter.submit(combined)
            summary.text = "${agents.size} whitelist, ${blacklisted.size} blacklist"
            progress.visibility = android.view.View.GONE
        }
    }
}
