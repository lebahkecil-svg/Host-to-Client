package com.example.netguardcontroller

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Menjaga server portal unduh APK tetap hidup selagi panel kontrol dipakai. */
class LandingService : Service() {

    companion object {
        const val PORT = 8080
        const val CHANNEL_ID = "netguard_landing"
        const val NOTIF_ID = 2
        var isRunning = false
            private set
    }

    private var server: LandingServer? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "NetGuard Portal", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, notif())
        if (server == null) {
            server = LandingServer(applicationContext, PORT).also { it.start() }
        }
        isRunning = true
        return START_STICKY
    }

    override fun onDestroy() {
        server?.stop(); server = null
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notif(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Portal unduh aktif")
            .setContentText("Perangkat baru bisa memindai QR untuk memasang aplikasi")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setOngoing(true)
            .build()
}
