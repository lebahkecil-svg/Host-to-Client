package com.example.netguardcontroller

import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Mencari alamat IPv4 kartu hotspot HP ini (biasanya antarmuka "ap0" atau "swlan0",
 * kadang "wlan0" tergantung merek HP). Tidak ada API resmi untuk ini, jadi dicoba
 * semua antarmuka non-loopback dan dipilih yang paling masuk akal.
 */
object HotspotIp {
    fun detect(): String? {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces()?.toList() ?: return null
            // Prioritaskan nama antarmuka yang umum dipakai untuk hotspot Android.
            val priorityNames = listOf("ap0", "swlan0", "wlan1", "wlan0")
            val candidates = interfaces.filter { it.isUp && !it.isLoopback }

            for (pname in priorityNames) {
                candidates.firstOrNull { it.name == pname }?.let { nic ->
                    ipv4Of(nic)?.let { return it }
                }
            }
            // Jika tidak ada nama yang cocok, ambil IP pertama yang bukan loopback.
            for (nic in candidates) {
                ipv4Of(nic)?.let { return it }
            }
            null
        } catch (e: Exception) { null }
    }

    private fun ipv4Of(nic: NetworkInterface): String? =
        nic.inetAddresses.toList()
            .filterIsInstance<Inet4Address>()
            .firstOrNull { !it.isLoopbackAddress }
            ?.hostAddress
}
