package com.example.netguardcontroller

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

private const val SERVICE_TYPE = "_netguard._tcp."
private const val TAG = "NetGuardController"

/**
 * Menemukan semua perangkat yang menjalankan NetGuard Agent di jaringan lokal
 * yang sama, lewat NSD (mDNS). Perangkat yang ditemukan di sini otomatis
 * dianggap whitelist, karena hanya agen resmi yang mendaftarkan layanan ini.
 */
class AgentDiscovery(private val ctx: Context) {

    private val nsd by lazy { ctx.getSystemService(Context.NSD_SERVICE) as NsdManager }

    /** Memindai selama [timeoutMs], mengembalikan daftar perangkat whitelist yang ditemukan. */
    suspend fun discover(timeoutMs: Long = 4000): List<AgentDevice> = suspendCancellableCoroutine { cont ->
        val found = mutableListOf<AgentDevice>()
        var finished = false

        fun finish() {
            if (finished) return
            finished = true
            try { nsd.stopServiceDiscovery(discoveryListener) } catch (_: Exception) {}
            if (cont.isActive) cont.resume(found)
        }

        val discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onServiceFound(service: NsdServiceInfo) {
                nsd.resolveService(service, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(s: NsdServiceInfo, code: Int) {
                        Log.w(TAG, "resolve gagal untuk ${s.serviceName}: $code")
                    }
                    override fun onServiceResolved(s: NsdServiceInfo) {
                        val host = s.host?.hostAddress ?: return
                        found.add(AgentDevice(name = s.serviceName, host = host, port = s.port, whitelisted = true))
                    }
                })
            }
            override fun onServiceLost(service: NsdServiceInfo) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { finish() }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }

        try {
            nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            if (cont.isActive) cont.resume(found)
            return@suspendCancellableCoroutine
        }

        cont.invokeOnCancellation { try { nsd.stopServiceDiscovery(discoveryListener) } catch (_: Exception) {} }

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ finish() }, timeoutMs)
    }
}
